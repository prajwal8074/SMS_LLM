---
title: Realistic Text To Speech Unlimited
emoji: 🔥
colorFrom: indigo
colorTo: purple
sdk: gradio
sdk_version: 5.28.0
app_file: app.py
pinned: true
short_description: Free Text-To-Speech generator with Emotion control (OpenAI)
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference